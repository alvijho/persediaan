<html>
    <head>
        <title><?php echo $judul; ?></title>
    </head>
    <body>                        
    <h1>Insert Data User</h1>
    <form action="simpan_user" method="post">
        <table> 
            <tr>
                <td>Nama Lengkap</td>
                <td><input type="text" name="nm_lengkap"/></td>
            </tr>
            <tr>
                <td>Username</td>
                <td><input type="text" name="username"/></td>
            </tr>
            <tr>
                <td>Password</td>
                <td><input type="password" name="password"/></td>
            </tr>
            </tr>
                <td>Email</td>
                <td><input type="text" name="email"/></td>
            </tr>
            <tr>
                <td>Alamat</td>
                <td><textarea name="alamat" style="height: 80px;"></textarea></td>
            <tr>
                <td></td>
                <td><input type="submit" value="Simpan"/></td>
            </tr>
        </table>


        <h2>Daftar User</h2>
    <table border="1">
        <thead>
        <tr>
            <th>Nama Lengkap</th>
            <th>Username</th>
            <th>Email</th>
            <th>Alamat</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
            <?php
                foreach($daftar_user as $user){
        ?>
                <tr>
            <td><?php echo $user->nm_lengkap; ?></td>
            <td><?php echo $user->username; ?></td>
            <td><?php echo $user->email; ?></td>
            <td><?php echo $user->alamat; ?></td>
            <td><?php echo '<a href="'.base_url().'index.php/user_controller/delete_user/'.$user->id_user.'" onclick="return confirm(\'Anda yakin akan menghapus '.$user->username.'?\')">Delete</a>'?></td>
            <td><?php echo '<a href="'.base_url().'user_controller/edit_user/'.$user->id_user.'">Edit</a>'?></td>
        </tr>
           <?php } ?>
    </tbody>
   
    </table>
    </form>
    </body>
</html>

