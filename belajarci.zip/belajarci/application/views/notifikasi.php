<html>
<head>
    <title><?php echo $judul; ?></title>
</head>
<body>
    <p><?php echo $notifikasi; ?></p>
</body>
</html>