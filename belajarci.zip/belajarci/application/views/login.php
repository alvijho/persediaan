<!DOCTYPE html 
  PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <title><?php echo $judul;?></title>      
    </head>
        <body>
        <div id="wrapper">
            <div id="spacer">  
            </div>
            <div id="konten">
                <div id="left-side">
                    <?php $this->load->view('includes/left-side-login');?>
                </div>
 
                <div id="right-side">
                        <h1>SEKOLAH MENENGAH ATAS STATISTIK</h1>
                        <br/><br/><br/>
                        <h2>Login</h2>
                        <p><?php if(isset($notifikasi)) echo $notifikasi;?></p>
                        <?php
                        $attributes = array('id' => 'login-form');
                        echo form_open('login/validate_login', $attributes);
                        ?>
 
                            <table id="log-tabel">
                                <tr>
                                    <td>Username</td>
                                    <td><input type="text" name="username" class="log-form" value="" maxlength="1024"/></td>
                                </tr>
                                <tr>
                                    <td>Password</td>
                                    <td><input type="password" name="password" class="log-form" value="" maxlength="1024"/></td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td><input type="submit" value="" class="login-button"/></td>
                                </tr>
                            </table>
                        <?php
                        echo form_close();
                        ?>
 
                        <p>Jika anda belum mempunyai username dan password silahkan aktifkan akun anda terlebih dahulu dengan menghubungi admin</p>           
                </div>  
           
        </div>
        </div>        
    </body>
</html>