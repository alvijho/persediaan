<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class User_controller extends CI_Controller{
 
    function __Construct()
    {
        parent ::__construct();
        $this->load->model('user_model');
    }
 
    function index()
    {
        $data['judul'] = 'Insert Data User';
        $data['juduls'] = 'Menampilkan Data dari Database Menggunakan Codeigniter';
        $data['daftar_user'] = $this->user_model->get_user_all();
        $this->load->view('user', $data);
     
    }
 
    function simpan_user()
    {     
        $this->user_model->simpan_user();
        $data['notifikasi'] = 'Data berhasil disimpan';
        $data['judul']='Insert Data Berhasil';
        redirect('user_controller/user');
    }

    function delete_user($id_user)
    {
      
        $username = $this->user_model->delete_user($id_user);
        redirect('user_controller/user');
    }
    
    function edit_user($id_user)
    {
        $data['edit']=$this->user_model->edit_user($id_user);
        $this->load->view('edit_user', $data);
    }
 
    function simpan_edit_user()
    {
        $id_user = $this->input->post('id_user');
        $nm_lengkap = $this->input->post('nm_lengkap');
        $username = $this->input->post('username');
        $password = $this->input->post('password');
        $email = $this->input->post('email');
        $alamat = $this->input->post('alamat');
 
        $data['judul'] = 'Update Data Codeigniter';
        $this->load->model('user_model');
        $data['edit'] = $this->user_model->simpan_edit_user($id_user, $nm_lengkap, $username, $password, $email, $alamat);
       redirect('user_controller/user');
       
    }  
}