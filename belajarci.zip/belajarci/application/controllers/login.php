<?php
class Login extends CI_Controller{
 
    public function index()
    {
        $data['judul'] = 'Web Portal › SIMATIK';
        $this->load->view('login', $data);    
    }
 
    function validate_login(){
 
        $this->load->model('user_model');
        $query = $this->user_model->validate();
 
        if($query){
 
            $data = array(
                'username' => $this->input->post('username'),
                'is_logged_in' => TRUE           
            );
 
            $this->session->set_userdata($data);
            redirect('site/home');      
        }else{
 
            $this->index();                  
        }   
    }
}